from django.apps import AppConfig


class PovregConfig(AppConfig):
    name = 'povreg'
